package com.example.audiocapture;

import android.media.AudioTrack;
import android.support.v4.view.MotionEventCompat;

public class PlayMusic {
    private static AudioTrack audioTrack;
    private final int sampleRate;

    /* renamed from: com.example.audiocapture.PlayMusic.1 */
    class C00901 implements Runnable {
        C00901() {
        }

        public void run() {
            PlayMusic.audioTrack.play();
        }
    }

    public PlayMusic(boolean on, boolean resistance) {
        this.sampleRate = 44000;
        PlayMusic playMusic;
        if (logicalXOR(on, resistance)) {
            playMusic = new PlayMusic(1, 0, 1);
        } else {
            playMusic = new PlayMusic(10000, 100, 0);
        }
    }

    private static boolean logicalXOR(boolean x, boolean y) {
        return (x || y) && !(x && y);
    }

    public PlayMusic(int frequency, int volume, int duration) {
        int actualDuration;
        this.sampleRate = 44000;
        if (duration == 0) {
            actualDuration = 10;
        } else {
            actualDuration = duration;
        }
        byte[] generatedSnd = genTone(frequency, volume, actualDuration);
        stop();
        audioTrack = new AudioTrack(3, 44000, 2, 2, generatedSnd.length * 2, 0);
        audioTrack.write(generatedSnd, 0, generatedSnd.length);
        if (duration == 0) {
            audioTrack.setLoopPoints(0, generatedSnd.length / 2, -1);
        }
        new Thread(new C00901()).start();
    }

    private void stop() {
        if (audioTrack != null) {
            audioTrack.stop();
            audioTrack.release();
        }
    }

    private byte[] genTone(int frequency, int volume, int duration) {
        int numSamples = duration * 44000;
        double[] sample = new double[numSamples];
        byte[] generatedSnd = new byte[(numSamples * 2)];
        for (int i = 0; i < numSamples; i++) {
            sample[i] = Math.sin((6.283185307179586d * ((double) i)) / ((double) (44000 / frequency)));
        }
        volume = Math.min(100, volume);
        int idx = 0;
        for (double dVal : sample) {
            short val = (short) ((int) ((320.0d * dVal) * ((double) volume)));
            int i2 = idx + 1;
            generatedSnd[idx] = (byte) (val & MotionEventCompat.ACTION_MASK);
            idx = i2 + 1;
            generatedSnd[i2] = (byte) ((MotionEventCompat.ACTION_POINTER_INDEX_MASK & val) >>> 8);
        }
        return generatedSnd;
    }
}
