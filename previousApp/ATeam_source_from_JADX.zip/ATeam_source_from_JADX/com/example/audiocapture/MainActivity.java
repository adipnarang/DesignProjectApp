package com.example.audiocapture;

import android.app.Activity;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.widget.ToggleButton;
import java.io.IOException;

public class MainActivity extends Activity {
    private boolean canActivateReplay;
    private Sensor mProximity;
    private SensorManager mSensorManager;
    private MuscleMouse muscleMouse;
    private Button muscleMouseButton;
    private Button proximityButton;
    private ProximityListener proximityListener;
    private Button replayButton;
    private boolean tenKActive;
    private Button tenKButton;
    private ToggleButton toggleButton;

    public MainActivity() {
        this.tenKActive = false;
        this.muscleMouse = null;
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0091R.layout.activity_main);
        this.muscleMouseButton = (Button) findViewById(C0091R.id.button1);
        this.tenKButton = (Button) findViewById(C0091R.id.button2);
        this.proximityButton = (Button) findViewById(C0091R.id.button3);
        this.replayButton = (Button) findViewById(C0091R.id.button4);
        this.toggleButton = (ToggleButton) findViewById(C0091R.id.toggleButton1);
        this.toggleButton.setVisibility(4);
        this.replayButton.setEnabled(false);
        this.canActivateReplay = false;
    }

    public void muscleMouseAction(View view) throws IllegalArgumentException, SecurityException, IllegalStateException, IOException {
        if (this.muscleMouse == null) {
            this.muscleMouse = new MuscleMouse(this, 750);
            display("MuscleMouse activated");
            this.replayButton.setEnabled(false);
            this.tenKButton.setEnabled(false);
            this.proximityButton.setEnabled(false);
            this.toggleButton.setEnabled(false);
            return;
        }
        this.muscleMouse.setActive(false);
        this.muscleMouse = null;
        display("MuscleMouse DEactivated");
        this.canActivateReplay = true;
        this.replayButton.setEnabled(this.canActivateReplay);
        this.tenKButton.setEnabled(true);
        this.proximityButton.setEnabled(true);
        this.toggleButton.setEnabled(true);
    }

    public void tenKAction(View view) {
        boolean z;
        PlayMusic playMusic;
        if (this.tenKActive) {
            playMusic = new PlayMusic(true, ((ToggleButton) findViewById(C0091R.id.toggleButton1)).isChecked());
            display("Manually Switching OFF 10k!");
            this.replayButton.setEnabled(this.canActivateReplay);
            this.muscleMouseButton.setEnabled(true);
            this.proximityButton.setEnabled(true);
            this.toggleButton.setEnabled(true);
        } else {
            playMusic = new PlayMusic(false, ((ToggleButton) findViewById(C0091R.id.toggleButton1)).isChecked());
            display("Manually Switching ON 10k!");
            this.replayButton.setEnabled(false);
            this.muscleMouseButton.setEnabled(false);
            this.proximityButton.setEnabled(false);
            this.toggleButton.setEnabled(false);
        }
        if (this.tenKActive) {
            z = false;
        } else {
            z = true;
        }
        this.tenKActive = z;
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(C0091R.menu.main, menu);
        return true;
    }

    public void onToggleClicked(View view) {
        PlayMusic playMusic = new PlayMusic(true, ((ToggleButton) view).isChecked());
    }

    public void proximityAction(View view) throws IllegalArgumentException, SecurityException, IllegalStateException, IOException {
        this.mSensorManager = (SensorManager) getSystemService("sensor");
        this.mProximity = this.mSensorManager.getDefaultSensor(8);
        if (this.proximityListener == null) {
            this.proximityListener = new ProximityListener(this);
            this.mSensorManager.registerListener(this.proximityListener, this.mProximity, 3);
            display("Proximity Sensor Activated!");
            this.replayButton.setEnabled(false);
            this.muscleMouseButton.setEnabled(false);
            this.tenKButton.setEnabled(false);
            this.toggleButton.setEnabled(false);
            return;
        }
        this.mSensorManager.unregisterListener(this.proximityListener, this.mProximity);
        this.proximityListener = null;
        display("Proximity Sensor DEActivated!");
        this.replayButton.setEnabled(this.canActivateReplay);
        this.muscleMouseButton.setEnabled(true);
        this.tenKButton.setEnabled(true);
        this.toggleButton.setEnabled(true);
    }

    public void replay(View view) {
        Replay replay = new Replay(this);
    }

    private void display(String input) {
        Toast.makeText(getApplicationContext(), input, 0).show();
    }
}
