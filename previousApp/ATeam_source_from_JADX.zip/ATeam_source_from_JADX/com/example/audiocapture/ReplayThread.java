package com.example.audiocapture;

import android.app.Activity;
import android.widget.ToggleButton;
import java.io.File;
import java.io.FileInputStream;

public class ReplayThread implements Runnable {
    private final Activity activity;

    public ReplayThread(Activity activity) {
        this.activity = activity;
    }

    public void run() {
        boolean flexed;
        Utility.display("Replaying previous signals from Muscle Mouse", this.activity);
        File file = new File(new StringBuilder(String.valueOf(this.activity.getApplicationContext().getFilesDir().getAbsolutePath())).append("/").append(MuscleMouseThread.FILENAME).toString());
        byte[] bytes = new byte[((int) file.length())];
        try {
            FileInputStream in = new FileInputStream(file);
            in.read(bytes);
            in.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        String inputString = new String(bytes);
        if (inputString.charAt(0) == '0') {
            flexed = true;
        } else {
            flexed = false;
        }
        for (int x = 0; x < inputString.length(); x++) {
            char c = inputString.charAt(x);
            PlayMusic playMusic;
            if (c == '1' && !flexed) {
                flexed = !flexed;
                playMusic = new PlayMusic(false, ((ToggleButton) this.activity.findViewById(C0091R.id.toggleButton1)).isChecked());
                Utility.display("Replay: DEA ON", this.activity);
            } else if (c == '0' && flexed) {
                flexed = !flexed;
                playMusic = new PlayMusic(true, ((ToggleButton) this.activity.findViewById(C0091R.id.toggleButton1)).isChecked());
                Utility.display("Replay: DEA OFF", this.activity);
            }
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e2) {
                e2.printStackTrace();
            }
        }
        Utility.display("Finished Replaying", this.activity);
    }
}
