package com.example.audiocapture;

import android.app.Activity;
import android.media.AudioRecord;
import android.os.Vibrator;
import android.widget.ToggleButton;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class MuscleMouseThread implements Runnable {
    public static final String FILENAME = "playback-data.txt";
    private static final int RECORDER_AUDIO_ENCODING = 2;
    private static final int RECORDER_CHANNELS = 16;
    private static final int RECORDER_SAMPLERATE = 8000;
    private Boolean active;
    private final Activity activity;
    private boolean flexed;
    private AudioRecord recorder;
    private final int threshold;
    private final boolean vibrate;

    public MuscleMouseThread(Activity a, int threshold, boolean vibrate) {
        this.activity = a;
        this.flexed = true;
        this.recorder = null;
        this.active = Boolean.valueOf(true);
        this.threshold = threshold;
        this.vibrate = vibrate;
    }

    public void run() {
        this.recorder = new AudioRecord(1, RECORDER_SAMPLERATE, RECORDER_CHANNELS, RECORDER_AUDIO_ENCODING, 1600);
        this.recorder.startRecording();
        short[] sData = new short[800];
        FileOutputStream stream = null;
        try {
            stream = new FileOutputStream(new File(new StringBuilder(String.valueOf(this.activity.getApplicationContext().getFilesDir().getAbsolutePath())).append("/").append(FILENAME).toString()));
        } catch (Exception e) {
            e.printStackTrace();
        }
        boolean updated = true;
        while (updated) {
            this.recorder.read(sData, 0, 800);
            int sum = 0;
            for (int x = 0; x < 800; x++) {
                sum += Math.abs(sData[x]);
            }
            int avg = sum / 800;
            System.out.println(avg);
            try {
                if (avg > this.threshold) {
                    stream.write("1".getBytes());
                } else {
                    stream.write("0".getBytes());
                }
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            if (avg > this.threshold && !this.flexed) {
                this.flexed = !this.flexed;
                vibrate();
                PlayMusic playMusic = new PlayMusic(false, ((ToggleButton) this.activity.findViewById(C0091R.id.toggleButton1)).isChecked());
                Utility.display("DEA is ON", this.activity);
            }
            if (avg < this.threshold && this.flexed) {
                this.flexed = !this.flexed;
                vibrate();
                playMusic = new PlayMusic(true, ((ToggleButton) this.activity.findViewById(C0091R.id.toggleButton1)).isChecked());
                Utility.display("DEA is OFF", this.activity);
            }
            try {
                Thread.sleep(100);
            } catch (InterruptedException e2) {
                e2.printStackTrace();
            }
            synchronized (this.active) {
                updated = this.active.booleanValue();
            }
        }
        this.recorder.stop();
        try {
            stream.close();
        } catch (IOException e3) {
            e3.printStackTrace();
        }
    }

    public synchronized void setActive(boolean active) {
        synchronized (this.active) {
            this.active = Boolean.valueOf(active);
        }
    }

    private void vibrate() {
        if (this.vibrate) {
            ((Vibrator) this.activity.getApplicationContext().getSystemService("vibrator")).vibrate(500);
        }
    }
}
