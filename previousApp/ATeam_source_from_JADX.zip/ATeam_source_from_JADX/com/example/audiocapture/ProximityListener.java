package com.example.audiocapture;

import android.app.Activity;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.widget.ToggleButton;

public class ProximityListener implements SensorEventListener {
    private final Activity activity;

    public ProximityListener(Activity activity) {
        this.activity = activity;
    }

    public final void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    public final void onSensorChanged(SensorEvent event) {
        if (event.values[0] > 3.0f) {
            PlayMusic playMusic = new PlayMusic(true, ((ToggleButton) this.activity.findViewById(C0091R.id.toggleButton1)).isChecked());
            Utility.display("Proximity: Turning DEA OFF", this.activity);
            return;
        }
        playMusic = new PlayMusic(false, ((ToggleButton) this.activity.findViewById(C0091R.id.toggleButton1)).isChecked());
        Utility.display("Proximity: Turning DEA ON!", this.activity);
    }
}
