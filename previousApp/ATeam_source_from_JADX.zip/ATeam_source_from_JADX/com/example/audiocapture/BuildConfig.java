package com.example.audiocapture;

public final class BuildConfig {
    public static final boolean DEBUG = true;
}
