package com.example.audiocapture;

import android.app.Activity;

public class Replay {
    private ReplayThread replayThread;

    public Replay(Activity input) {
        this.replayThread = new ReplayThread(input);
        new Thread(this.replayThread).start();
    }
}
