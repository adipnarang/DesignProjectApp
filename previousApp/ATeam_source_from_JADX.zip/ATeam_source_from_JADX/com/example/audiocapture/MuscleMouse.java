package com.example.audiocapture;

import android.app.Activity;

public class MuscleMouse {
    private MuscleMouseThread muscleThread;

    public MuscleMouse(Activity a, int threshold) {
        this.muscleThread = new MuscleMouseThread(a, threshold, false);
        new Thread(this.muscleThread).start();
    }

    public void setActive(boolean b) {
        this.muscleThread.setActive(b);
    }
}
