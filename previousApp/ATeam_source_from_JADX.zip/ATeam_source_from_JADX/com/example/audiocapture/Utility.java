package com.example.audiocapture;

import android.app.Activity;
import android.widget.Toast;

public class Utility {

    /* renamed from: com.example.audiocapture.Utility.1 */
    class C00921 implements Runnable {
        private final /* synthetic */ Activity val$activity;
        private final /* synthetic */ String val$input;

        C00921(Activity activity, String str) {
            this.val$activity = activity;
            this.val$input = str;
        }

        public void run() {
            Toast.makeText(this.val$activity.getApplicationContext(), this.val$input, 0).show();
        }
    }

    public static void display(String input, Activity activity) {
        activity.runOnUiThread(new C00921(activity, input));
    }
}
