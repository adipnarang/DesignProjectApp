package android.support.v7.view;

public interface CollapsibleActionView {
    void onActionViewCollapsed();

    void onActionViewExpanded();
}
