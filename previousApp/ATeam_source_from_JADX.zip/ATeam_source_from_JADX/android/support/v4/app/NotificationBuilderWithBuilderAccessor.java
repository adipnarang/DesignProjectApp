package android.support.v4.app;

import android.app.Notification.Builder;

interface NotificationBuilderWithBuilderAccessor {
    Builder getBuilder();
}
