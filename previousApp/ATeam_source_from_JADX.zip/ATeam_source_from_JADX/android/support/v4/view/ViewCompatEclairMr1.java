package android.support.v4.view;

import android.view.View;

class ViewCompatEclairMr1 {
    ViewCompatEclairMr1() {
    }

    public static boolean isOpaque(View view) {
        return view.isOpaque();
    }
}
